1. ¿Qué diferencias encuentras entre las dos soluciones?

En la Parte A utilizamos estilos en línea, escribiéndolos directamente en las etiquetas HTML. En la Parte B utilizamos estilos internos, escribiéndolos dentro de la etiqueta style en el head.

2. ¿Qué sucede si queremos aplicar el mismo estilo a diez páginas?

   Con los estilos en línea tendríamos que modificar cada página por separado. Con los estilos internos también tendríamos que repetir los estilos en cada página.

3. ¿Qué modalidad utilizarías en un proyecto real?

Utilizaría una hoja de estilos externa (CSS), porque permite aplicar los mismos estilos a varias páginas, facilita los cambios y mantiene el código más organizado.